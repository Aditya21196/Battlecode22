package defensivebot2.strategies;

import battlecode.common.MapLocation;

public class Pathfinding {

    public void moveTowards(MapLocation target){
        // check if path to target is cached which isn't more than 5 turns old

        // find angle to target
        // delta y / delta x

        // fetch iterable tiles in arc across line to target

    }

    public void moveAwayFrom(MapLocation target){
        // find tiles in direction opposite to target

        // find the one easiest to reach

    }

}
