package defensivebot.bots;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class WatchTower extends Robot{
    public WatchTower(RobotController rc) throws GameActionException  {
        super(rc);
    }

    @Override
    public void sense() throws GameActionException {
        
    }

    @Override
    public void move() throws GameActionException {

    }

    @Override
    public void executeRole() throws GameActionException {

    }
}
