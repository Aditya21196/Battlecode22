package defensivebot.bots;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class Sage extends Robot{
    public Sage(RobotController rc) throws GameActionException  {
        super(rc);
    }

    @Override
    public void sense() throws GameActionException {

    }

    @Override
    public void move() throws GameActionException {

    }

    @Override
    public void executeRole() throws GameActionException {

    }
}
