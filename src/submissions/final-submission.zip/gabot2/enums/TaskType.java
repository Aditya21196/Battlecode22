package gabot2.enums;

public enum TaskType {

    ATTACK_ARCHON,
    DEFEND_ARCHON,
    EXPLORE,
    BUILD_WATCHTOWER;

}
